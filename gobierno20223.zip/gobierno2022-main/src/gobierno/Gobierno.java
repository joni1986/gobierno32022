
package gobierno;

import login.inicio;
import login.menu;


public class Gobierno {

  //kkkk
    public static void main(String[] args) {
        System.out.println(" hola mundo"); 
        System.out.println(" casa una caraga"); 
        inicio.main(args);
    }
    
}
